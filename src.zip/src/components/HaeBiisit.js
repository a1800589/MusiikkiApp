import React, { Component } from 'react';
import MenuMUI from '../navigation/MenuMUI';
import KappalelistaMUI from '../components/KappalelistaMUI';

const url = 'http://localhost:8080';
class HaeBiisit extends Component {
constructor(props) {
super(props);
this.state = {kappale: [], virhe: ''};
}
componentDidMount = () => {
this.haeKaikkiBiisit();
}
haeKaikkiBiisit = () => {
return fetch(url + '/kappale/all')
.then((response) => response.json())
.then((responseJson) => {
this.setState({kappale: responseJson, virhe: ''});
})
.catch((error) => {
this.setState({kappale: [], virhe: 'Tietojen haku ei onnistunut'});
})
}
render() {
return (<KappalelistaMUI kappale={kappalelista}/> + 'mahdollisen virheilmoituksen näyttäminen')
}
}
export default HaeBiisit;
